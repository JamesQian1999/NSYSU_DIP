B073021024 錢承

1.Packages:
	Used tkinter, PIL, numpy, matplotlib.pyplot and math packages

	Installation :         
		sudo apt-get install python3
		sudo apt-get install python3-tk     
		sudo apt-get install python3-pil python3-pil.imagetk
		sudo apt-get install python3-numpy
		sudo apt-get install python3-matplotlib
		sudo apt-get install python3-opencv
		sudo apt-get install python3-pip
		sudo pip3 install opencv

2.Environment:
	Distributor ID: 	Ubuntu
	Description:    	Ubuntu 20.04.1 LTS
	Release:        	20.04
	Codename:       	focal

3.Python version:
	Python 3.8.5

4.Graphics display resolution:
	1920 x 1080
